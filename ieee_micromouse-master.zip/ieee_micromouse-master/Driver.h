/*
 * Thermistor.h - Library for calculating the temperature of the AL block based on thermistor.
 * based on resistance changes.
 * 
 * Created by Adam Li, November 23, 2013.
 * Released into public domain for EWH usage
 */